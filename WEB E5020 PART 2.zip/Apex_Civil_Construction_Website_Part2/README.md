# Apex Civil & Construction Services Website

WED module Proof of Evidence (PoE) website project.

## Pages
index.html, about.html, services.html, enquiry.html, contact.html

## Technologies
HTML5, CSS3 (Grid, Flexbox, custom properties, media queries) and JavaScript.

## Organisation
A fictional South African construction and civil engineering organisation created for academic purposes.

## Project Structure
```
Apex_Civil_Construction_Website/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── images/
│   ├── gallery-1/2/3-480/800/1200.jpg    (responsive srcset illustrations)
│   ├── team-desktop.jpg, team-mobile.jpg (art-directed <picture> images)
│   └── hero-art.jpg                       (hero illustration)
├── screenshots/
│   └── ...                                (breakpoint evidence, see below)
├── research/
│   └── Content-Research.txt
└── README.md
```

## Part 2 — CSS Styling and Responsive Design

### 1. Feedback from Part 1
No formal written feedback had been released for Part 1 at the time of this
submission, so a general review and cleanup pass was carried out instead.
See the Changelog below for the specific changes made.

### 2. CSS Styling for Desktop Solution
- **External stylesheet:** a single `css/style.css` is linked from every
  page using a consistent `<link rel="stylesheet" href="css/style.css">`.
- **CSS reset:** section 1 of the stylesheet normalises margins, box-sizing,
  list styles and image display across browsers.
- **Base style & typography scale:** CSS custom properties (`:root`) define
  the colour palette and a rem-based typographic scale (`--fs-sm` through
  `--fs-xxl`) so every heading and paragraph traces back to one root size.
- **Layout structure:** Flexbox is used for the header/nav bar
  (`display:flex; justify-content:space-between; align-items:center`), and
  CSS Grid with named `grid-template-areas` is used for the hero section and
  the footer (`"brand links contact"`), keeping the number of selectors
  needed to a minimum thanks to the cascade.
- **Visual styles:** `color`, `background-color`, `border` and `box-shadow`
  are used on cards, buttons and the image gallery, with `:hover`, `:focus`
  (`:focus-visible`) and `:active` pseudo-classes on links, buttons and form
  fields for clear interactive feedback.

### 3. Responsive Design
- **Breakpoints:** a desktop-first cascade with two media queries —
  `max-width: 1024px` (tablet) and `max-width: 600px` (mobile) — switches
  the services cards, project gallery and footer from a multi-column grid
  to a single column, and reduces navigation, heading sizes and spacing.
- **Relative units:** the typography scale and spacing system use `rem`,
  component padding/gaps use `rem`/`em`-friendly values, and the page
  container uses `%`-based width with a `max-width` cap.
- **Responsive images:**
  - The "Recent Projects" gallery on `index.html` uses `srcset`/`sizes` on a
    single `<img>` so the browser picks the best resolution for the
    viewport (480w / 800w / 1200w).
  - The "Our Team on Site" image on `about.html` uses a `<picture>` element
    with two `<source media>` entries to serve a differently cropped image
    on mobile vs desktop (art direction), not just a scaled-down copy.
- **Test and iterate:** the site was checked with browser developer tools
  at desktop, tablet and mobile widths (see Screenshot Evidence below).

### Screenshot Evidence
Real screenshots captured with a headless browser at each breakpoint are
included in the `screenshots/` folder:

**Home page**

![Desktop view](screenshots/index-desktop.png)
![Tablet view](screenshots/index-tablet.png)
![Mobile view](screenshots/index-mobile.png)

**About Us page**

![About desktop](screenshots/about-desktop.png)
![About tablet](screenshots/about-tablet.png)
![About mobile](screenshots/about-mobile.png)

**Services page (desktop)**

![Services desktop](screenshots/services-desktop.png)

**Contact page (desktop)**

![Contact desktop](screenshots/contact-desktop.png)

If you make further changes, re-capture screenshots the same way: open each
page in Chrome or Edge, open DevTools (`F12`) → Device Toolbar
(`Ctrl+Shift+M`), set the width to `1440px` (desktop), `900px` (tablet) and
`390px` (mobile), and use DevTools' "Capture screenshot" command
(`Ctrl+Shift+P`) at each size.

### Colour Palette
The design is restricted to four colours, applied consistently through
CSS custom properties rather than one-off hex values:
- **White** (`#ffffff`) — page background, card surfaces
- **Black** (`#10130f`) — body text, borders, dark shapes in the illustrations
- **Green** (`#1f6f43` / `#12472b`) — header, footer, hero background, stats
  strip
- **Gold** (`#d4af37`) — links, buttons, card accents, highlights in the
  illustrations

### Images
The gallery images, hero illustration and "Our Team on Site" picture-element
images are original flat-style illustrations created for this project (a
house build, a bridge/excavator scene, a road-paving scene, and worker
silhouettes on site), drawn strictly in the white/black/green/gold palette
above so they sit consistently with the rest of the design. They are
provided as JPGs at the widths referenced in each `srcset` so the responsive
image techniques in section 3.3 can be demonstrated and inspected in
DevTools' Network panel.

## Changelog

### Part 2 — revision 2
- Restricted the entire colour system to white, black, green and gold,
  replacing the original navy/orange palette in every CSS variable, shadow
  tint and hover state.
- Replaced the placeholder gallery/hero/team images with original flat-style
  construction illustrations (house build, bridge/excavator scene, road
  paving scene, on-site worker silhouettes) drawn in the new palette.
- Added a stats strip (years of experience, projects completed, branches,
  safety commitment) to the Home and About pages.
- Added a testimonials section to the Home page.
- Expanded written content across the site: fuller service descriptions, a
  4-step "Our Process" section on Services, an "Areas We Serve" section and
  extended values/mission/vision/safety content on About, and business
  hours plus a general-enquiries note on Contact.
- Added a gold top-accent border and hover-lift effect to all cards for a
  more distinctive, professional look.
- Captured genuine desktop/tablet/mobile screenshots with a headless
  browser and added them to `screenshots/` for the evidence section above.

### Part 2 — revision 1
- Replaced the Part 1 stylesheet with a fully organised `style.css`
  (reset → variables/typography scale → base → typography → layout →
  components → responsive), documented with section comments.
- Introduced a rem-based typographic scale and a shared colour/spacing
  variable system used across every page.
- Rebuilt the footer on all five pages as a three-column CSS Grid
  (`grid-template-areas: "brand links contact"`) with quick links and
  contact details, collapsing to two then one column at the tablet and
  mobile breakpoints.
- Added `:hover`, `:focus-visible` and `:active` states to navigation
  links, the call-to-action button and all form fields.
- Added a "Recent Projects" image gallery to `index.html` using `srcset`
  and `sizes` for responsive image loading.
- Added an "Our Team on Site" section to `about.html` using a `<picture>`
  element with art-directed sources for mobile vs desktop.
- Replaced the default bulleted list on the "Why Choose Apex?" section
  with a custom `.checklist` style (the reset removes default list
  styling, so a `::before` check-mark was added back deliberately).
- Added two responsive breakpoints (tablet ≤1024px, mobile ≤600px) in
  place of the single Part 1 breakpoint, covering cards, gallery, hero,
  footer and typography.
- General cleanup pass over Part 1 markup: consistent footer structure
  across pages, `aria-label` added to the footer navigation, alt text
  reviewed on new images, and CSS variables replacing repeated hex/pixel
  values for easier maintenance.

### Part 1
- Initial five-page website (Home, About Us, Services, Enquiry, Contact)
  built with semantic HTML5, a shared header/nav and footer, an enquiry
  form and a contact form with basic client-side validation
  (`js/script.js`), and an initial responsive stylesheet with one
  breakpoint.

## References
- Mozilla Developer Network (MDN Web Docs). *CSS Grid Layout, Flexbox,
  Media Queries, srcset/sizes, the picture element.*
  https://developer.mozilla.org/en-US/docs/Web/CSS
- Mozilla Developer Network (MDN Web Docs). *Responsive images.*
  https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- W3Schools. *CSS Reference.* https://www.w3schools.com/css/
- The Independent Institute of Education (Pty) Ltd. *WED module Part 2
  brief: Designing the Visuals — CSS Styling and Responsive Design.* 2026.

## Testing
Tested in Chrome (headless, via automated screenshots — see above) and
should also be checked manually in Edge and Firefox, confirming mobile,
tablet and desktop layouts at the breakpoints noted above.

## GitHub Repository
- Commit changes regularly with descriptive commit messages.
- Push all local changes to the remote repository.
- Submit the GitHub repository link to the Learning Management System.
